#include <iostream>
#include "Liaison.hpp"

#include <string>   // for strings
#include <iomanip>  // for controlling float print precision
#include <sstream>  // string to number conversion
#include <vector>

#include <opencv4/opencv2/core.hpp>     // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv4/opencv2/imgproc.hpp>  // Gaussian Blur
#include <opencv4/opencv2/videoio.hpp>
#include <opencv4/opencv2/highgui.hpp>  // OpenCV window I/O
#include <opencv4/opencv2/imgcodecs.hpp>

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

using namespace std;
using namespace cv;
using namespace sf;

class Transmission : public Messager
{
public:
	Transmission(Liaison *comm)
	{
		m_activ = false;
		m_cible = false;
		comm->addMsger('V',this);
	};
	virtual void recepteur(char* data,int size)
	{
		cout << size << endl;
		Color tempo;int value;
		try {if (m_img[!m_cible].loadFromMemory(data,size))
		{
			m_X = m_img[!m_cible].getSize().x;
			m_Y = m_img[!m_cible].getSize().y;
			for (int x=0;x<m_X;x++)
				for (int y=0;y<m_Y;y++)
				{
					tempo = m_img[!m_cible].getPixel(x,y);
					value = tempo.r;
					tempo.r = tempo.b;
					tempo.b = value;
					m_img[!m_cible].setPixel(x,y,tempo);
				}
			m_cible=!m_cible;
			m_activ=true;
		}}
		catch (...) {}
	};
	Image getImg()
	{
		return m_img[m_cible];
	};
	
	bool m_activ;
	int m_X,m_Y;
private:
	Image m_img[2];
	bool m_cible;
};

class Show : public Messager
{
	public:
	Show(){}
	virtual void recepteur(char* data,int size)
	{
		cout << endl;
		for (int i=0;i<size;i++)
			cout << data[i];
	}
};

void send(Liaison *comm)
{
	char data[7];
	for (int i = 0;i<7;i++)
		data[i] = (unsigned char)0;
	data[0] = (unsigned char)(100-Joystick::getAxisPosition(0, sf::Joystick::Z));
	data[1] = data[0];
	data[2] = (unsigned char)(100+Joystick::getAxisPosition(0, sf::Joystick::X));
	data[4] = (unsigned char)(100+Joystick::getAxisPosition(0, sf::Joystick::Y));
	data[3] = (unsigned char)(100+0.75*Joystick::getAxisPosition(0, sf::Joystick::PovX));
	//data[5] = (unsigned char)(100-Joystick::getAxisPosition(0, sf::Joystick::PovX));
	/*cout << Joystick::getAxisPosition(0, sf::Joystick::Z) << " ";
	cout << Joystick::getAxisPosition(0, sf::Joystick::X) << " ";
	cout << Joystick::getAxisPosition(0, sf::Joystick::PovX) << " ";
	cout << Joystick::getAxisPosition(0, sf::Joystick::Y) << "\n";*/
	for (int i = 0;i<6;i++)
		data[6] = data[6] ^ data[i];
	comm->send('C',data,7);
}

void Communique(Liaison *comm)
{
	string saisie="";
	
	while (true)
	{
		cout << "Commande (A,M,I,R): ";
		cin >> saisie;
		char c = saisie[0];
		comm->send('A',&c,1);
	}
}


int main()
{
	Liaison comm("/dev/ttyUSB0");
	Show show;
	comm.addMsger('I',&show);
	Transmission trans(&comm);
	/*while (!trans.m_activ)
		sleep(seconds(0.01));*/
	
	RenderWindow window(sf::VideoMode(800,600), "WebCam");
	Sprite sprite;
	Texture texture;
	
	if (!Joystick::isConnected(0))
	{
		cout << "Joystick not found.\n";
		return 1;
	}
	Thread thread(&Communique,&comm);
	thread.launch();
	
	while (window.isOpen())
	{
		// on traite tous les évènements de la fenêtre qui ont été générés depuis la dernière itération de la boucle
		sf::Event event;
		while (window.pollEvent(event))
		{
			// fermeture de la fenêtre lorsque l'utilisateur le souhaite
			if (event.type == sf::Event::Closed)
			window.close();
		}
		Joystick::update();
		send(&comm);

		// effacement de la fenêtre en noir
		window.clear(sf::Color::Black);
		
		//modifImg(img);
		if (trans.m_activ)
		{
			texture.loadFromImage(trans.getImg(),IntRect(0,0,trans.m_X,trans.m_Y));
			sprite.setTexture(texture);
			window.draw(sprite);
		}

		// fin de la frame courante, affichage de tout ce qu'on a dessiné
		sleep(seconds(0.1));
		window.display();
	}
	thread.terminate();
	return 0;
}
