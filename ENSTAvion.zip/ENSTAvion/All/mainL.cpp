#include <iostream>
#include "Massager.h"
#include "serialib.h"
#include <unistd.h>
#include <SFML/System.hpp>

using namespace std;

class Liaison : public Messager
{
public:
	Liaison(string port) : 
	{
		m_serial.openDevice(port.c_str(), 19200);
		recoit();
	};
	~Liaison()
	{m_serial.closeDevice();}
	virtual void recepteur(char *data,int taille)
	{
		for (int i=0;i<taille;i++)
		{
			m_serial.writeChar(data[i]);
			usleep(30);
		}
	};
	void recoit()
	{
		char data[10000];
		char c;
		bool lire = false;
		int compte = 0;
		while (true)
		{
			m_serial.readChar(&c);
			if (c=='F')
			{
				lire = false;
				m_entrer.send(data,compte);
				compte=0;
			}
			else if (c=='D')
			{
				lire = true;
			}
			else if (lire)
			{
				data[compte]=c;
				compte++;
			}
			if (compte==10000)
			{
				compte=0;
				lire = false;
			}
		}
	}
private:
	ROS_Troll_S m_entrer;
	ROS_Troll_R m_sortie;
	
	serialib m_serial;
};

int main()
{
	
	Liaison("/dev/ttyUSB0");
	
	return 0;
	
}
