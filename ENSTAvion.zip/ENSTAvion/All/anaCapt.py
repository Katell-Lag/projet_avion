import numpy as np

File = open("donnees_enregistrees.txt")

lignes = File.readlines()
Magn = []
Gyro = []
print(lignes)
for i in range(1,len(lignes)-1):	
	tempo = lignes[i][0:len(lignes[i])-1]
	tempo = tempo.split("=")
	valeurs = tempo[1].split(",")
	sortie = []
	for k in range(3):
		sortie.append(float(valeurs[k]))
	if (tempo[0]=="#M-R"):
		Magn.append(sortie)
	if (tempo[0]=="#G-R"):
		Gyro.append(sortie)

Magn = np.array(Magn)
Gyro = np.array(Gyro)

File.close()

print("Magneto : ")
print(Magn)
print("Gyroscop: ")
print(Gyro)

print("Gyro : ",np.mean(Gyro,0))
MaxM = np.max(Magn,0)
MinM = np.min(Magn,0)
Centre = (MaxM+MinM)/2
Ampli = 1/(MaxM-Centre)
print("Centre :",Centre)
print("1/Ampl :",Ampli)
