#include "VECTEUR3.h"

Vecteur3::Vecteur3(double X,double Y,double Z)
{m_v[0]=X;m_v[1]=Y;m_v[2]=Z;}

Vecteur3::Vecteur3(const Vecteur3& a)
{for (int i = 0;i<3;i++)m_v[i]=a.m_v[i];}


double Vecteur3::norm()
{
	double somme=0;
	for (int i = 0;i<3;i++)
		somme+=m_v[i]*m_v[i];
	return sqrt(somme);
}

double Vecteur3::sum()
{
	return m_v[0]+m_v[1]+m_v[2];
}

Vecteur3& Vecteur3::operator+=(const Vecteur3 &c)
{	for (int i = 0;i<3;i++)
		m_v[i]+=c.m_v[i];
	return *this;}

Vecteur3& Vecteur3::operator-=(const Vecteur3 &c)
{	for (int i = 0;i<3;i++)
		m_v[i]-=c.m_v[i];
	return *this;}

Vecteur3& Vecteur3::operator*=(const Vecteur3 &c)
{	for (int i = 0;i<3;i++)
		m_v[i]*=c.m_v[i];
	return *this;}




Vecteur3& Vecteur3::operator+=(const double &c)
{	for (int i = 0;i<3;i++)
		m_v[i]+=c;
	return *this;}

Vecteur3& Vecteur3::operator-=(const double &c)
{	for (int i = 0;i<3;i++)
		m_v[i]-=c;
	return *this;}

Vecteur3& Vecteur3::operator*=(const double &c)
{	for (int i = 0;i<3;i++)
		m_v[i]*=c;
	return *this;}

Vecteur3& Vecteur3::operator/=(const double &c)
{	for (int i = 0;i<3;i++)
		m_v[i]/=c;
	return *this;}




Vecteur3 operator+(Vecteur3 const& a,Vecteur3 const& b)
{	Vecteur3 copie(a);
	copie += b;
	return copie;}

Vecteur3 operator-(Vecteur3 const& a,Vecteur3 const& b)
{	Vecteur3 copie(a);
	copie -= b;
	return copie;}

Vecteur3 operator*(Vecteur3 const& a,Vecteur3 const& b)
{	Vecteur3 copie(a);
	copie *= b;
	return copie;}




Vecteur3 operator*(double const& a,Vecteur3 const& b)
{	Vecteur3 copie(b);
	copie *= a;
	return copie;}

Vecteur3 operator/(Vecteur3 const& a,double const& b)
{	Vecteur3 copie(a);
	copie /= b;
	return copie;}

Vecteur3 operator+(Vecteur3 const& a,double const& b)
{	Vecteur3 copie(a);
	copie += b;
	return copie;}

Vecteur3 operator-(Vecteur3 const& a,double const& b)
{	Vecteur3 copie(a);
	copie -= b;
	return copie;}


