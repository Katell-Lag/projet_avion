g++ -std=c++11 mainO.cpp serialib.cpp -O2 -o ordi -lopencv_videoio -lopencv_core -lopencv_imgproc -lopencv_highgui -lopencv_imgcodecs -lsfml-system -lsfml-graphics -lsfml-window -lsfml-network
