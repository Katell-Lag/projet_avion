#ifndef CAPTEUR_H_INCLUDED
#define CAPTEUR_H_INCLUDED

#define COEFF_GYRO 0.06957*3.14159265359/180.
#define DEG_TO_RAD (3.14159265359/180.)
#define _CONF_M_ 0.01
#define _PI_ 3.14159265359

#include <iostream>
#include "serialib.h"
#include <unistd.h>
#include <fstream>
#include <SFML/System.hpp>
#include <vector>
#include "Liaison.hpp"
#include "VECTEUR3.h"


using namespace std;
using namespace sf;

class Capteur
{
public:
	Capteur(Liaison *liaisonGPS,Liaison *liaisonIn) : m_threadGPS(&Capteur::Th_GPS,this), m_threadIn(&Capteur::Th_In,this)
	{
		m_activ = false;
		m_activGPS = false;
		m_liaisonGPS = liaisonGPS;
		m_liaisonIn  = liaisonIn;
		
		m_GPS    = Vecteur3(0,0,0);
		m_Euler  = Vecteur3(0,0,0);
		m_omega  = Vecteur3(0,0,0);
		
		
		ifstream File("configCapt.txt");
		string saisie;
		File >> saisie >> m_diff_angle;
		m_diff_angle *= _PI_/180.;
		File >> saisie >> m_ampliAcc;
		File.close();
		
		m_clockA.restart();
		m_clockG.restart();
		
		m_threadGPS.launch();
		m_threadIn.launch();
	}
	void finit()
	{
		m_threadGPS.terminate();
		m_threadIn.terminate();
	}
	bool activ()
	{return m_activ && m_activGPS;}
	
	Vecteur3 getGPS()
	{
		Vecteur3 retour;
		m_mutexGPS.lock();
		retour = m_GPS;
		m_mutexGPS.unlock();
		return retour;
	}
	Vecteur3 getEuler()
	{
		Vecteur3 retour;
		m_mutexIMU.lock();
		retour = m_Euler;
		m_mutexIMU.unlock();
		return retour;
	}
	Vecteur3 getOmega()
	{
		Vecteur3 retour;
		m_mutexIMU.lock();
		retour = m_omega;
		m_mutexIMU.unlock();
		return retour;
	}
	
	void affiche()
	{
		Vecteur3 omega = getOmega();
		Vecteur3 euler = getEuler();
		Vecteur3 GPS   = getGPS();
		
		if (m_activ)
		{
			cout << "IMU ACTIVE :\n";
			cout << "Angle Euler :\n";
			cout <<euler.m_v[0]<<" "<<euler.m_v[1]<<" "<<euler.m_v[2]<<endl;
			cout << "Omega       :\n";
			cout <<omega.m_v[0]<<" "<<omega.m_v[1]<<" "<<omega.m_v[2]<<endl;
		}
		else
			cout << "IMU NON ACTIVE !\n";
		cout << endl;
		if (m_activGPS)
		{
			cout << "GPS ACTIVE :\n";
			cout << "GPS :\n";
			cout <<GPS.m_v[0]/DEG_TO_RAD<<" "<<GPS.m_v[1]/DEG_TO_RAD<<" "<<GPS.m_v[2]<<endl;
		}
		else
			cout << "GPS NON ACTIVE !\n";
		cout << endl << endl;
	}
private:
	
	vector<string> divise(int taille,char data[])
	{
		vector<string> retour;
		string tempo="";
		for (int i=0;i<taille;i++)
		{
			if (data[i]==',' || data[i]=='=')
			{
				retour.push_back(tempo);
				tempo = "";
			}
			else
				tempo = tempo + data[i];
		}
		retour.push_back(tempo);
		return retour;
	}
	
	void Th_In()
	{
		int taille;
		char data[1000];
		while(true)
		{
			taille = m_liaisonIn->lecture(data);
			vector<string> liste = divise(taille,data);
			if (liste.size() >= 5)
			{
				if (liste[0]=="#YPRAG")
				{
					m_mutexIMU.lock();
					
					try{
					
					m_Euler.m_v[0] = stod(liste[1])*DEG_TO_RAD;
					m_Euler.m_v[1] = stod(liste[2])*DEG_TO_RAD;
					m_Euler.m_v[2] = stod(liste[3])*DEG_TO_RAD;
					
					m_omega.m_v[0] = stod(liste[7]);
					m_omega.m_v[1] = stod(liste[8]);
					m_omega.m_v[2] = stod(liste[9]);
					
					m_activ = true;
					
					}catch(...){cout<<"ERROR DATA!\n";}
					
					m_mutexIMU.unlock();
				}
			}
		}
	}
	
	double GPS_To_Angle(string entrer)
	{
		double value = stod(entrer);
		double retour = (int)(value/100.);
		retour += (value-100*retour)/60.;
		return retour;
	}
	void Th_GPS()
	{
		int taille;
		char data[1000];
		while(true)
		{
			taille = m_liaisonGPS->lecture(data);
			vector<string> liste = divise(taille,data);
			if (liste.size() >= 13)
			{
				if (liste[0]=="$GPGGA")
				{
					if (liste[2].size()>0)
					{
						m_mutexGPS.lock();
						try{
						
						m_GPS.m_v[0] = GPS_To_Angle(liste[2])*DEG_TO_RAD;
						m_GPS.m_v[1] = GPS_To_Angle(liste[4])*DEG_TO_RAD;
						m_GPS.m_v[2] = stod(liste[9]);
						if (liste[3]!="N")
							m_GPS.m_v[0] *= -1;
						if (liste[5]!="W")
							m_GPS.m_v[1] *= -1;
						m_activGPS = true;
						
						}catch(...){cout<<"ERROR DATA!\n";}
						
						m_mutexGPS.unlock();
					}
					else
						m_activGPS = false;
				}
			}
		}
	}
	
	
	
	
	Liaison *m_liaisonGPS;
	Liaison *m_liaisonIn;
	Thread m_threadGPS,m_threadIn;
	Clock m_clockA,m_clockG;
	
	Vecteur3 m_Euler, m_omega, m_GPS;
	double m_diff_angle;
	double m_ampliAcc;
	bool m_activ,m_activGPS;
	Mutex m_mutexIMU,m_mutexGPS;
};

#endif
