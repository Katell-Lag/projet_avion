#ifndef VECTEUR3_H_INCLUDED
#define VECTEUR3_H_INCLUDED

#include <iostream>
#include <cmath>

using namespace std;

class Vecteur3
{
public:
	Vecteur3(double X=0,double Y=0,double Z=0);
	Vecteur3(const Vecteur3& a);
	
	double norm();
	double sum();

	Vecteur3& operator+=(const Vecteur3 &c);
	Vecteur3& operator-=(const Vecteur3 &c);
	
	Vecteur3& operator*=(const Vecteur3 &c);
	
	Vecteur3& operator+=(const double &c);
	Vecteur3& operator-=(const double &c);

	Vecteur3& operator*=(const double &c);
	Vecteur3& operator/=(const double &c);
	

	double m_v[3];
};

Vecteur3 operator+(Vecteur3 const& a,Vecteur3 const& b);
Vecteur3 operator-(Vecteur3 const& a,Vecteur3 const& b);
Vecteur3 operator*(Vecteur3 const& a,Vecteur3 const& b);

Vecteur3 operator*(double const& a,Vecteur3 const& b);
Vecteur3 operator/(Vecteur3 const& a,double const& b);
Vecteur3 operator+(Vecteur3 const& a,double const& b);
Vecteur3 operator-(Vecteur3 const& a,double const& b);


#endif // VECTEUR3_H_INCLUDED
