#include <iostream>
#include "Liaison.hpp"
#include "Capteur.hpp"
#include "Auto.hpp"
#include "Camera.hpp"


using namespace std;

class Transfert : public Messager
{
public:
	Transfert(Liaison *arduino):m_arduino(arduino),m_thread(&Transfert::run,this)
	{m_thread.launch();m_change=false;m_autonom=false;}
	virtual void recepteur(char* data,int size)
	{
		if (size==7)
		{
			char val = (unsigned char) 0;
			for (int i = 0;i<6;i++)
				val = val ^ data[i];
			if (val==data[6])
			{
				/*for (int i=0;i<size;i++)
					cout << (int)(unsigned char)data[i] << " ";
				cout << m_autonom<< endl;*/
				m_change = true;
				if (!m_autonom)
					m_arduino->send('N',data,size);
			}
		}
	}
	void run()
	{
		char data[7];
		data[0] = (unsigned char) 0;
		data[1] = (unsigned char) 0;
		data[2] = (unsigned char) 100;
		data[3] = (unsigned char) 100;
		data[4] = (unsigned char) 100;
		data[5] = (unsigned char) 100;
		data[6] = (unsigned char) 0;
		for (int i = 0;i<6;i++)
			data[6] = data[6] ^ data[i];
		while (true)
		{
			if (!m_change)
				m_arduino->send('N',data,7);
			m_change = false;
			sleep(seconds(1.5));
		}
	}
	
	bool m_autonom;
private:
	Liaison *m_arduino;
	Thread m_thread;
	bool m_change;
};

int main()
{
	Liaison commu("/dev/ttyUSB0");
	//Camera camera(&commu);
	//camera.start();
	Liaison arduino("/dev/ttyAMA0",57600,true);
	Liaison lien_GPS("/dev/ttySOFT0",4800,true);
	
	
	Transfert trans(&arduino);
	Capteur capteur(&lien_GPS,&arduino);
	Auto autono(&arduino,&commu,&capteur,&(trans.m_autonom));
	
	commu.addMsger('C',&trans);
	commu.addMsger('A',&autono);
	
	while (true)
	{
		//capteur.affiche();
		sleep(seconds(5.0));
	}
	cout << "Terminer ? : ";
	string saisie;
	cin >> saisie;
	//camera.stop();
	return 0;
}
