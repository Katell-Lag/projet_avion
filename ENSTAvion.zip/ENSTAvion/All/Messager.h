class Messager
{
public:
	Messager(){};
	virtual void recepteur(char* data,int size){};
};
