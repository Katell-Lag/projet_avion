#include <iostream>
#include "serialib.h"

using namespace std;

int main()
{
	serialib serial;
	string adresse;int baudrate;
	cout << "Nom port : ";
	cin >> adresse;
	cout << "Baudrate : ";
	cin >> baudrate;
	serial.openDevice(adresse.c_str(), baudrate);
	char c;
	while(true)
	{
		serial.readChar(&c);
		cout << c;
	}
	return 0;
}
