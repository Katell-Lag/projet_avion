g++ Ecoute.cpp serialib.cpp -o ecoute
