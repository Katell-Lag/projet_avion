Ajouter liaison série :

https://github.com/sfera-labs/soft_uart

Installer opencv sur la rasp:
sudo apt-get install libopencv-dev

Fichier pour l'ordi :

goO.sh

mainO.cpp
serialib.cpp

Liaison.hpp

serialib.h


Fichier pour le drone :

goD.sh

mainD.cpp
serialib.cpp
jpeg.cpp

Liaison.hpp
Capteur.hpp
Auto.hpp
Camera.hpp

serialib.h
jpeg.h
