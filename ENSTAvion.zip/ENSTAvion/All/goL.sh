g++ mainL.cpp ROS_Troll_cpp.cpp serialib.cpp -O2 -o liaison -lsfml-system -lsfml-network
