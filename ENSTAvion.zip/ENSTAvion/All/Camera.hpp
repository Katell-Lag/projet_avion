#ifndef CAMERA_H_INCLUDED
#define CAMERA_H_INCLUDED

#include "Liaison.hpp"

#include <iostream> // for standard I/O
#include <string>   // for strings
#include <iomanip>  // for controlling float print precision
#include <sstream>  // string to number conversion
#include <vector>
#include <fstream>

#include <opencv2/core.hpp>     // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/imgproc.hpp>  // Gaussian Blur
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>  // OpenCV window I/O
#include <opencv2/imgcodecs.hpp>

#include <SFML/System.hpp>

#include "jpge.h"

using namespace std;
using namespace sf;
using namespace cv;

class Camera
{
public:
	Camera(Liaison *commu) : m_cam(0),m_commu(commu),m_thread_Cam(&Camera::cam,this),m_thread_Tra(&Camera::tra,this)
	{
		if (!m_cam.isOpened())
		{
			cout  << "Could not open reference 0" << endl;
			return;
		}
		m_over = true;
	}
	void start()
	{
		m_over = false;
		m_thread_Cam.launch();
		m_thread_Tra.launch();
	}
	void stop()
	{m_over=true;m_thread_Cam.wait();m_thread_Tra.wait();}	
private:
	void cam()
	{
		Mat frame;
		while (!m_over)
		{
			m_cam.read(frame);
			double fact = 360./frame.size().width;
			m_mutex.lock();
				resize(frame, m_petite, Size(), fact,fact);
			m_mutex.unlock();
		}
	}
	void tra()
	{
		jpge::params para;
		para.m_quality=10;
		
		char result[10000];
		int taille=10000;
		
		sleep(seconds(10));
		while (!m_over)
		{
			taille=10000;
			m_mutex.lock();
				jpge::compress_image_to_jpeg_file_in_memory(result,taille,m_petite.size().width,m_petite.size().height,3,m_petite.data,para);
			m_mutex.unlock();
			m_commu->send('V',result,taille);
		}
	}

	VideoCapture m_cam;
	Liaison *m_commu;
	Thread m_thread_Cam;
	Thread m_thread_Tra;
	
	sf::Mutex m_mutex;
	Mat m_petite;
	
	bool m_over;
};

#endif
