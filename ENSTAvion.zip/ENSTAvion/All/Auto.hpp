#ifndef AUTO_H_INCLUDED
#define AUTO_H_INCLUDED

#define _PI_ 3.14159265359
#define DEG_TO_RAD (3.14159265359/180.)

#include <iostream>
#include <fstream>
#include <cmath>
#include "Liaison.hpp"
#include "VECTEUR3.h"
#include "Capteur.hpp"

#include <SFML/System.hpp>

using namespace std;
using namespace sf;

class Auto : public Messager
{
public:
	Auto(Liaison *arduino,Liaison *commu,Capteur *capteur,bool *auto_):
	m_arduino(arduino),m_commu(commu),m_capteur(capteur),
	m_thread(&Auto::run,this)
	{
		m_refGPS = Vecteur3(0,0,0);
		m_ref = false;
		m_auto = auto_;
		
	}
	virtual void recepteur(char* data,int size)
	{
		if (size==1)
		{
			if (data[0] == 'A')
				Automatique();
			if (data[0] == 'M')
				Manuel();
			if (data[0] == 'I')
				Information();
			if (data[0] == 'R')
				Reference();
		}
	}
	
	void Automatique()
	{
		if (m_ref && *m_auto==false)
			m_thread.launch();
	}
	
	void Manuel()
	{
		*m_auto = false;
	}
	
	void Information()
	{
		string data = "Info| Ref:";
		if (m_ref)
			data = data + "V";
		else
			data = data + "X";
		data = " Auto:";
		if (*m_auto)
			data = data + "V";
		else
			data = data + "X";
		data = data + " refGPS:";
		data = data + " " + to_string(m_refGPS.m_v[0]/DEG_TO_RAD);
		data = data + " " + to_string(m_refGPS.m_v[1]/DEG_TO_RAD);
		data = data + " " + to_string(m_refGPS.m_v[2]/DEG_TO_RAD) + " ";
		
		char donnee[200];
		for (int i=0;i<data.size();i++)
			donnee[i] = data[i];
		m_commu->send('I',donnee,data.size());
	}
	
	void Reference()
	{
		if (m_capteur->activ())
		{
			m_refGPS = m_capteur->getGPS();
			m_ref = true;
		}
	}
private:
	void run()
	{
		string saisie = "";
		double X,Y,Z,R,P,T;
		Vecteur3 cible(0,0,0);
		
		*m_auto = true;
		ifstream File("target.txt");
		
		int nb_target;
		File >> saisie >> nb_target;
		
		for (int i = 0;i < nb_target ; i++)
		{
			File >> saisie >> X;
			File >> saisie >> Y;
			File >> saisie >> R;
			File >> saisie >> Z;
			File >> saisie >> P;
			File >> saisie >> T;
			cible = Vecteur3(X,Y,Z);
			
			tourne(cible,R,P,T);
		}
		
		File.close();
		*m_auto = false;
	}
	
	double atan2(Vecteur3 X)
	{
		X.m_v[2] = 0;
		if (X.norm()==0)
			return 0;
		X/=X.norm();
		double value = acos(X.m_v[0]);
		if (X.m_v[1]<0)
			value *= -1;
		return value;	
	}
	
	double mod2pi(double value)
	{
		value += 5*_PI_;
		value = value - ( (int)(value/(_PI_*2.)) )*_PI_*2.;
		return value - _PI_;
	}
	double rogner(double value, double Ampli)
	{
		if (value>Ampli)
			value = Ampli;
		if (value<-Ampli)
			value =-Ampli;
		return value;
	}
	void actionne(Vecteur3 commande,double P)
	{
		commande.m_v[0] = rogner(commande.m_v[0],1);
		commande.m_v[1] = rogner(commande.m_v[1],1);
		commande.m_v[2] = 0;
		char data[7];
		data[0] = (unsigned char) 200*P;
		data[1] = (unsigned char) 200*P;
		data[2] = (unsigned char) 100+100*commande.m_v[0];
		data[3] = (unsigned char) 100+100*commande.m_v[2];
		data[4] = (unsigned char) 100+100*commande.m_v[1];
		data[5] = (unsigned char) 100;
		data[6] = (unsigned char) 0;
		for (int i = 0;i<6;i++)
			data[6] = data[6] ^ data[i];
		m_arduino->send('N',data,7);
	}
	
	void tourne(Vecteur3 cible,double R,double P,double T)
	{
		Vecteur3 p_GPS,euler,omega,centrer,centrer2;
		Vecteur3 vitesse(0,0,0);
		Vecteur3 commande(0,0,0);
		Clock clock;
		clock.restart();
		while (clock.getElapsedTime().asSeconds() < T)
		{
			p_GPS = m_capteur->getGPS() - m_refGPS;
			p_GPS.m_v[0] *= 20000000/_PI_;
			p_GPS.m_v[1] *= 20000000*cos(m_refGPS.m_v[0])/_PI_;
			
			euler = m_capteur->getEuler();
			omega = m_capteur->getOmega();
			
			centrer = p_GPS - cible;
			centrer2= centrer;
			centrer2.m_v[0] = 0;
			
			double angleObj = -atan2(centrer) - _PI_/2 - atan((centrer2.norm()-R)/(15));
			angleObj = mod2pi(angleObj);
			
			double angleMont = -(centrer.m_v[2])/10.;
			angleMont = rogner(angleMont,30*DEG_TO_RAD);
			
			double diffAngle = mod2pi( angleObj - euler.m_v[0] );
			diffAngle = rogner(diffAngle,20*DEG_TO_RAD);
			
			vitesse.m_v[0] = diffAngle - euler.m_v[2];
			vitesse.m_v[1] = angleMont- euler.m_v[1];
			vitesse *= 5;
			vitesse.m_v[1] += 0.5*10*(1-cos(euler.m_v[2]))/R;
			
			commande = vitesse - omega;
			commande.m_v[2] = 0;
			commande *= 3;
			
			actionne(commande/15.,P);
			
			sleep(seconds(0.05));
		}
	}
	
	Thread m_thread;

	Liaison *m_arduino,*m_commu;
	Capteur *m_capteur;
	bool *m_auto;
	
	Vecteur3 m_refGPS;
	bool m_ref;
};

#endif
