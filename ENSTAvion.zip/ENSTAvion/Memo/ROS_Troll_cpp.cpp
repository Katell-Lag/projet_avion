#include "ROS_Troll_cpp.h"

ROS_Troll::ROS_Troll(string name,string adresse,int port)
{
	if (m_socket.bind(Socket::AnyPort) != sf::Socket::Done)
	{
		cout << "Erreur a l'ouverture du port\n";
	}
	m_adresse = adresse;
	m_port = port;
	m_name = name;
}

ROS_Troll::~ROS_Troll()
{
	m_socket.unbind();
}


ROS_Troll_S::ROS_Troll_S(string name,string adresse,int port) : ROS_Troll(name,adresse,port)
{
	
}

void ROS_Troll_S::send(char *data,int size,char type)
{
	char donnee[10000];
	donnee[0]=type;
	donnee[1]=m_name.size();
	for (int i=0;i<m_name.size();i++)
		donnee[2+i]=m_name[i];
	for (int i=0;i<size;i++)
		donnee[2+i+m_name.size()]=data[i];
	m_socket.send(donnee,2+size+m_name.size(),m_adresse,m_port);
}

void ROS_Troll_S::send(string data,char type)
{
	string header = "__";
	header[0]=type;
	header[1]=m_name.size();
	header+=m_name;
	header+=data;
	m_socket.send(header.c_str(),header.size(),m_adresse,m_port);
}

ROS_Troll_R::ROS_Troll_R(string name,void (*reception)(char*, int),string adresse,int port) : ROS_Troll_S(name,adresse,port), m_thread(&ROS_Troll_R::run, this)
{
	m_reception = reception;
	m_mode = true;
	char nul;
	send(&nul,0,'1');
	m_thread.launch();
}

ROS_Troll_R::ROS_Troll_R(string name,Messager *messager,string adresse,int port) : ROS_Troll_S(name,adresse,port), m_thread(&ROS_Troll_R::run, this)
{
	m_messager = messager;
	m_mode = false;
	char nul;
	send(&nul,0,'1');
	m_thread.launch();
}

void ROS_Troll_R::stop()
{
	m_thread.terminate();
}

void ROS_Troll_R::run()
{
	char data[10000];
	IpAddress sender;
	unsigned short port;
	size_t received;
	while (true)
	{
		if (m_socket.receive(data, 10000, received, sender, port) == sf::Socket::Done)
		{
			if (port == m_port)
			{
				if (m_mode)
					(*m_reception)(data,received);
				else
					m_messager->recepteur(data,received);
			}
		}
	}
}

ROS_Troll_Over::ROS_Troll_Over(string adresse,int port) : ROS_Troll_S("over",adresse,port)
{
	char nul;
	send(&nul,0,'0');
}

