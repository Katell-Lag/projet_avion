#ifndef CAPTEUR_H_INCLUDED
#define CAPTEUR_H_INCLUDED

#define COEFF_GYRO 0.06957*3.14159265359/180.
#define _CONF_M_ 0.01
#define _PI_ 3.14159265359

#include <iostream>
#include "serialib.h"
#include <unistd.h>
#include <fstream>
#include <SFML/System.hpp>
#include <vector>
#include "Liaison.hpp"
#include "unsupported/Eigen/MatrixFunctions"
 
using namespace Eigen;
using namespace std;

class Capteur
{
public:
	Capteur(Liaison *liaisonGPS,Liaison *liaisonIn) : m_threadGPS(&Capteur::Th_GPS,this), m_threadIn(&Capteur::Th_In,this),
	m_R(3,3), m_OmegaConst(3,1), m_CentrConst(3,1), m_AmpliConst(3,1), m_flecheM(3,1), m_g(3,1), m_GPS(3,1)
	{
		nb_iniM=0;
		nb_iniA=0;
		m_activ = false;
		m_activGPS = false;
		m_liaisonGPS = liaisonGPS;
		m_liaisonIn  = liaisonIn;
		
		
		m_R << 0, 0, 0,
		       0, 0, 0,
		       0, 0, 0;
		m_GPS << 0,0,0;
		m_flecheM << 0,0,0;
		m_g << 0,0,0;
		
		ifstream File("configCapt.txt");
		string saisie;
		double x,y,z;
		File >> saisie >> y >> x >> z;
		m_OmegaConst << x,y,z;
		File >> saisie >> y >> x >> z;
		m_CentrConst << x,y,z;
		File >> saisie >> y >> x >> z;
		m_AmpliConst << -x,-y,-z;
		File >> saisie >> m_diff_angle;
		m_diff_angle *= _PI_/180.;
		File >> saisie >> m_ampliAcc;
		File.close();
		
		m_clockA.restart();
		m_clockG.restart();
		
		m_threadGPS.launch();
		m_threadIn.launch();
	}
	void finit()
	{
		m_threadGPS.terminate();
		m_threadIn.terminate();
	}
	bool activ()
	{return m_activ;}
	bool activGPS()
	{return m_activGPS;}
	void afficheI()
	{cout << m_R << endl << endl << m_GPS << endl;}
private:
	MatrixXd adjoint(MatrixXd omega)
	{
		MatrixXd Rot(3,3);
		Rot << 0,-omega(2,0),omega(1,0),	omega(2,0),0,-omega(0,0),	-omega(1,0),omega(0,0),0;
		return Rot;
	}
	void Th_In()
	{
		int taille;
		char data[1000];
		MatrixXd Data(3,1);
		while(true)
		{
			taille = m_liaisonIn->lecture(data);
			if (data[0]=='#'){
			string tempo="";
			int mode=-3;
			char type='X';
			for (int i = 0;i<taille;i++)
			{
				if (mode >= 0)
				{
					if (data[i]==',')
					{
						Data(mode,0) = stod(tempo);
						mode += 1;
						tempo = "";
					}
					else
						tempo = tempo + data[i];
				}
				if (mode == -1 && data[i]=='=')
					mode = 0;
				if (mode == -2)
				{
					type = data[i];
					mode = -1;
				}
				if (mode == -3 && data[i]=='#')
					mode = -2;
			}
			Data(2,0) = stod(tempo);
			double echange = Data(0,0);
			Data(0,0)=Data(1,0);
			Data(1,0)=echange;
			if (m_activ)
			{
				if (type=='A');
				if (type=='M')
					magn(Data);
				if (type=='G')
					gyro(Data);
			}
			else
			{
				if (type=='A')
					ini_acce(Data);
				if (type=='M')
					ini_magn(Data);
				if (type=='G');
			}
			if (!m_activ && nb_iniM>=10 && nb_iniA>=10)
			{
				ini_R();
				m_activ = true;
			}
			}
		}
	}
	vector<string> divise(int taille,char data[],char c)
	{
		vector<string> retour;
		string tempo="";
		for (int i=0;i<taille;i++)
		{
			if (data[i]==c)
			{
				retour.push_back(tempo);
				tempo = "";
			}
			else
				tempo = tempo + data[i];
		}
		retour.push_back(tempo);
		return retour;
	}
	double GPS_To_Angle(string entrer)
	{
		double value = stod(entrer);
		double retour = (int)(value/100.);
		retour += (value-100*retour)/60.;
		return retour;
	}
	void Th_GPS()
	{
		int taille;
		char data[1000];
		while(true)
		{
			taille = m_liaisonGPS->lecture(data);
			vector<string> liste = divise(taille,data,',');
			if (liste.size() >= 13)
			{
				if (liste[0]=="$GPGGA")
				{
					if (liste[2].size()>0)
					{
						m_activGPS = true;
						m_GPS(0,0) = GPS_To_Angle(liste[2]);
						m_GPS(1,0) = GPS_To_Angle(liste[4]);
						m_GPS(2,0) = stod(liste[9]);
						if (liste[3]!="N")
							m_GPS(0,0) *= -1;
						if (liste[5]!="W")
							m_GPS(1,0) *= -1;
					}
					else
						m_activGPS = false;
				}
			}
		}
	}
	
	void gyro(MatrixXd omega)
	{
		omega -= m_OmegaConst;
		omega *= COEFF_GYRO*m_clockG.restart().asSeconds();
		MatrixXd Rot(3,3);
		Rot << 0,-omega(2,0),omega(1,0),	omega(2,0),0,-omega(0,0),	-omega(1,0),omega(0,0),0;
		m_R=m_R*Rot.exp();
	}
	
	void ini_R()
	{
		m_g = m_g.normalized();
		m_flecheM = m_flecheM.normalized();
		cout<<"G: "<<m_g<<endl;
		cout<<"M: "<<m_flecheM<<endl;
		cout << m_g*(m_g.transpose()*m_flecheM)<<endl;
		cout << "1\n";
		MatrixXd nord = m_flecheM - m_g*(m_g.transpose()*m_flecheM);
		cout << "1.5\n";
		nord = nord.normalized();
		cout << "2\n";
		MatrixXd ouest = adjoint(m_g)*nord;
		cout << adjoint(m_g)<<endl;
		cout << "2.5\n";
		
		m_R <<	nord(0,0)	,ouest(0,0)	,m_g(0,0),
			nord(1,0)	,ouest(1,0)	,m_g(1,0),
			nord(2,0)	,ouest(2,0)	,m_g(2,0);
		cout << "3\n";
		MatrixXd rot(3,1);
		rot << 0,0,-m_diff_angle;
		m_R = m_R * adjoint(rot).exp();
		m_flecheM = m_R.transpose() * m_flecheM;
	}
	
	void ini_acce(MatrixXd g)
	{
		g*=m_ampliAcc;
		if (nb_iniA<10)
		{
			m_g += g;
			nb_iniA++;
		}
	}
	
	void ini_magn(MatrixXd fleche)
	{
		fleche -= m_CentrConst;
		for (int i=0;i<3;i++)
			fleche(i,0) *= m_AmpliConst(i,0);
		if (nb_iniM<10)
		{
			m_flecheM += fleche;
			nb_iniM++;
		}
	}
	
	void magn(MatrixXd fleche)
	{
		fleche -= m_CentrConst;
		for (int i=0;i<3;i++)
			fleche(i,0) *= m_AmpliConst(i,0);
		fleche = fleche.normalized();
		MatrixXd estimer = m_R*m_flecheM;
		MatrixXd diff = fleche - estimer;
		double norme = diff.norm();
		if (diff.norm()!=0)
		{
			diff = diff.normalized();
			MatrixXd theta = adjoint(estimer)*diff;
			theta *= norme*_CONF_M_;
			m_R = m_R * adjoint(theta).exp();
		}
	}
	
	
	Liaison *m_liaisonGPS;
	Liaison *m_liaisonIn;
	Thread m_threadGPS,m_threadIn;
	Clock m_clockA,m_clockG;
	
	MatrixXd m_R;
	MatrixXd m_GPS;
	MatrixXd m_OmegaConst;
	MatrixXd m_CentrConst;
	MatrixXd m_AmpliConst;
	MatrixXd m_flecheM;
	MatrixXd m_g;
	double m_diff_angle;
	double m_ampliAcc;
	
	int nb_iniM,nb_iniA;
	bool m_activ,m_activGPS;
};

#endif
