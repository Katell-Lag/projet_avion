import socket
from threading import Thread

class ROS_Troll_S:
	def __init__(self,name,adresse="127.0.0.1",port=4242):
		self.adresse = adresse
		self.port = port
		self.sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		self.header = bytearray(b"2_"+name)
		self.header[1] = len(name)
	
	def send(self,data):
		self.sock.sendto(self.header+data, (self.adresse, self.port))

class ROS_Troll_R(Thread):
	def __init__(self,name,func,adresse="127.0.0.1",port=4242):
		Thread.__init__(self)
		self.adresse = adresse
		self.fin = False
		self.port = port
		self.func = func
		self.sock = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		self.header = bytearray(b"1_"+name)
		self.header[1] = len(name)
		self.sock.sendto(self.header, (self.adresse, self.port))
		self.start()
	
	def finit(self):
		self.fin = True
		self.join()
	
	def newFunc(self,func):
		self.func = func
	
	def run(self):
		self.sock.settimeout(1.)
		while not self.fin:
			try:
				data, addr = self.sock.recvfrom(10000)
				self.func(data)
			except:
				a=0
