#include <iostream>
#include <pigpiod_if2.h>
#include <unistd.h>

using namespace std;

class Servos
{
public:
	Servos()
	{
		port_roulis = ;
		port_assiette = ;
		port_lacet = ;
		port_MotD = ;
		port_MotG = ;
	}
private:
	int session;
	
	int port_roulis;
	int port_assiette;
	int port_lacet;
	int port_MotD;
	int port_MotG;
};
