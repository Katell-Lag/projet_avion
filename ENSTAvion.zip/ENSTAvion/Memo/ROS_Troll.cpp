#include <iostream>
#include <SFML/Network.hpp>
#include "ROS_Troll_cpp.h"
#include <fstream>
#include <vector>
#include <unistd.h>

using namespace std;
using namespace sf;

struct Recepteur
{
	string name;
	IpAddress adresse;
	unsigned short port;
};

struct Message
{
	char data[10000];
	int taille;
	float time;
};

void uint_to_char2(int value, char data[])
{
	data[0]= value%120;
	data[1]= value/120;
}

int char2_to_uint(char data[])
{
	return (int)(data[0]) + (int)(data[1])*120;
}

int launch(bool,string,int);
void replay(string,int,float);

int main(int argc, char *argv[])
{
	vector<string> para;
	for (int i=0;i<argc;i++)
		para.push_back(String(argv[i]));
	
	ifstream monFlux("config_ROS_Troll.txt");
	int PORT = 0;
	string saisie = "";
	if(monFlux)    
	{
		monFlux >> saisie >> PORT;
		cout << "PORT : " << PORT << endl;
	}
	else
	{
		cout << "ERREUR: Fichier config non trouve, PORT : 4242\n" << endl;
	}
	monFlux.close();
	
	if (para.size()>=2)
		if (para[1]=="over")
		{
			ROS_Troll_Over();
			return 0;
		}
	
	if (para.size()>=3)
		if (para[1]=="save")
			return launch(true,para[2],PORT);
	
	if (para.size()>=3)
		if (para[1]=="replay")
		{
			float vitesse=1;
			if (para.size()>=4)
				vitesse = stof(para[3]);
			replay(para[2],PORT,vitesse);
			return 0;
		}
	
	return launch(false,"",PORT);
}

bool section(ifstream &monFlux,Message &msg)
{
	char info[6];
	char c;
	for (int i=0;i<6;i++)
	{
		if (!monFlux.get(c))
			return false;
		info[i]=c;
	}
	msg.time = ((float)char2_to_uint(info)) + ((float)char2_to_uint(&info[2]))/10000.;
	msg.taille = char2_to_uint(&info[4]);
	for (int i=0;i<msg.taille;i++)
	{
		if (!monFlux.get(c))
			return false;
		msg.data[i]=c;
	}
	return true;
}

void replay(string adresse,int PORT,float vitesse)
{
	Message msg;
	UdpSocket socket;
	ifstream monFlux(adresse,ios::binary);
	if (socket.bind(Socket::AnyPort) != sf::Socket::Done)
	{
		cout << "Erreur a l'ouverture du port\n";
	}
	Clock clock;
	
	while (section(monFlux,msg))
	{
		float dt = msg.time/vitesse - clock.getElapsedTime().asSeconds();
		if (dt>0)
			usleep(dt*1000000);
		if (msg.data[0]=='2')
			socket.send(msg.data,msg.taille,"127.0.0.1",PORT);
	}
	
	clock.restart();
	
	
}

int launch(bool save,string adresseS,int PORT)
{
	char data[10000];
	ofstream Sauve;
	if (save)
		Sauve.open(adresseS.c_str(),ios::binary);
	
	
	Clock clock;
	clock.restart();
	
	vector<Recepteur> recepteur;
	
	UdpSocket socket;

	if (socket.bind(PORT) != sf::Socket::Done)
	{
		cout << "Erreur a l'ouverture du port\n";
		return 0;
	}
	
	bool finit = false;
	while (!finit)
	{
		IpAddress sender;
		unsigned short port;
		size_t received;
		socket.receive(data, 10000, received, sender, port);
		if (received>=2)
		{
			string msg(&data[2],int(data[1]));
			if (data[0]=='0') // System
			{
				if (msg=="over")
					finit = true;
			}
			if (data[0]=='1') // Connection
			{
				Recepteur nouveau;
				nouveau.name = msg;
				nouveau.adresse = sender;
				nouveau.port = port;
				recepteur.push_back(nouveau);
			}
			if (data[0]=='2') // Publication
			{
				for (int i=0;i<recepteur.size();i++)
					if (msg==recepteur[i].name)
						socket.send(&data[2+int(data[1])], received-2-int(data[1]), recepteur[i].adresse, recepteur[i].port);
			}
			if (save)
			{
				char c_temps[6];
				float temps=clock.getElapsedTime().asSeconds();
				uint_to_char2((int)temps,c_temps);
				uint_to_char2((int)((temps-(int)temps)*10000),&c_temps[2]);
				uint_to_char2(received,&c_temps[4]);
				for (int i=0;i<6;i++)
					Sauve.put(c_temps[i]);
				for (int i=0;i<received;i++)
					Sauve.put(data[i]);
			}
		}
	}
	if (save)
		Sauve.close();
	socket.unbind();
	return 0;
}
