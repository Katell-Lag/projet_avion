class Messager;

#ifndef ROS_TROLL_CPP_H_INCLUDED
#define ROS_TROLL_CPP_H_INCLUDED

#include <iostream>
#include <SFML/System.hpp>
#include <SFML/Network.hpp>
#include <fstream>
#include <vector>

using namespace std;
using namespace sf;

class Messager
{
public:
	Messager(){};
	virtual void recepteur(char* data,int size){};
};

class ROS_Troll
{
public:
	ROS_Troll(string name,string adresse="127.0.0.1",int port=4242);
	~ROS_Troll();	
protected:
	UdpSocket m_socket;
	string m_adresse;
	int m_port;
	string m_name;
};

class ROS_Troll_S : public ROS_Troll
{
public:
	ROS_Troll_S(string name,string adresse="127.0.0.1",int port=4242);
	void send(char* data,int size,char type='2');
	void send(string data,char type='2');
};

class ROS_Troll_R : public ROS_Troll_S
{
public:
	ROS_Troll_R(string name,void (*reception)(char*, int),string adresse="127.0.0.1",int port=4242);
	ROS_Troll_R(string name,Messager *messager,string adresse="127.0.0.1",int port=4242);
	void run();
	void stop();
private:
	Thread m_thread;
	void (*m_reception)(char*, int);
	bool m_mode;
	Messager *m_messager;
};

class ROS_Troll_Over : public ROS_Troll_S
{
public:
	ROS_Troll_Over(string adresse="127.0.0.1",int port=4242);
};

#endif
