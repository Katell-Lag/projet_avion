
struct Donnee;
class Communication;

#include "ROS_Troll_cpp.h"

#ifndef COMMUNICATION_H_INCLUDED
#define COMMUNICATION_H_INCLUDED

#include <iostream>
#include <vector>

using namespace std;

struct Donnee
{
	char data[10000];
	int taille;
};

class Communication : public Messager
{
public:
	Communication();
	virtual void recepteur(char* data,int size);
	void send(char type,char *data,int taille);
	void addMsger(char c,Messager *msger);
private:
	ROS_Troll_S m_sortie;
	ROS_Troll_R m_entrer;
	
	string m_data;
	Mutex m_mutexExpe;
	
	Donnee m_donneeS;
	
	vector<char> m_Id;
	vector<Messager*> m_func;
};

#endif
