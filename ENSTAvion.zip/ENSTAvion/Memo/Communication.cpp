#include "Communication.h"

Communication::Communication() : m_sortie("sortie"),m_entrer("entrer",this)
{
}

void Communication::recepteur(char* data,int size)
{
	char data_R[10000];
	int compteur = 0;
	bool special=false;
	for (int i=0;i<size;i++)
	{
		if (special)
		{
			if (data[i]=='1')
				data_R[compteur]='D';
			else if (data[i]=='2')
				data_R[compteur]='F';
			else
				data_R[compteur]=data[i];
			compteur++;
			special=false;
		}
		else
		{
			if (data[i]=='\\')
				special=true;
			else if (data[i]!='D' && data[i]!='F')
			{
				data_R[compteur]=data[i];
				compteur++;
			}
		}
	}
	for (int i=0;i<m_Id.size();i++)
		if (m_Id[i]==data_R[0])
			m_func[i]->recepteur(&data_R[1],compteur-1);
	
}

void Communication::addMsger(char c,Messager *msger)
{
	m_Id.push_back(c);
	m_func.push_back(msger);
}


void Communication::send(char type,char *data,int taille)
{
	m_mutexExpe.lock();
	m_donneeS.data[0]='D';
	m_donneeS.data[1]=type;
	int compteur = 2;
	for (int i=0;i<taille;i++)
	{
		if (data[i]=='D')
		{
			m_donneeS.data[compteur] = '\\';
			compteur++;
			m_donneeS.data[compteur] = '1';
			compteur++;
		}
		else if (data[i]=='F')
		{
			m_donneeS.data[compteur] = '\\';
			compteur++;
			m_donneeS.data[compteur] = '2';
			compteur++;
		}
		else if (data[i]=='\\')
		{
			m_donneeS.data[compteur] = '\\';
			compteur++;
			m_donneeS.data[compteur] = '\\';
			compteur++;
		}
		else
		{
			m_donneeS.data[compteur] = data[i];
			compteur++;
		}
	}
	m_donneeS.data[compteur] = 'F';
	compteur++;
	m_sortie.send(m_donneeS.data,compteur);
	m_mutexExpe.unlock();
}

