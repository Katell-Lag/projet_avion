import serial
import time

ser = serial.Serial()
ser.port = "/dev/ttyUSB1"
ser.baudrate = 115200

ser.open()
fin = True

compte=0
err=0
while fin:
	x = ser.read()
	if (x[0]==65):
		compte+=1
	elif (x[0]==70):
		fin =False
	else:
		err+=1
print(compte)
print(err)

ser.close()
