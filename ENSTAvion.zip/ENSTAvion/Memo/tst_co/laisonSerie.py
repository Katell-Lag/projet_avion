import serial
from threading import Thread

class Liaison(Thread):
	def __init__(self,name,baudrate,func):
		Thread.__init__(self)
		self.ser = serial.Serial()
		self.ser.port = name
		self.ser.baudrate = baudrate
		self.ser.open()
		self.fin = False
		self.func = func
	
	def finit(self):
		self.fin = True
	
	def newFunc(self,func):
		self.func = func
	
	def envoi(self,data):
		self.ser.write(data)
	
	def run(self):
		data=bytearray(b"")
		for i in range(20000):
			data+=b'_'
		lire = False
		compte = 0
		while not self.fin:
			x = self.ser.read()
			if x[0]==70:
				lire = False
				self.func(data[0:compte])
				compte=0
			elif x[0]==68:
				lire = True
			elif lire:
				data[compte] = x[0]
				compte+=1
		self.ser.close()
		
