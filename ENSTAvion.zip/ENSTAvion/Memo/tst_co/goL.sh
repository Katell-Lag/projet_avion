g++ mainL.cpp serialib.cpp -O2 -o liaison -lsfml-system -lsfml-network
