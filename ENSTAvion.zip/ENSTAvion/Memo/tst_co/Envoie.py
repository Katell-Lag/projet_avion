import serial
import time

ser = serial.Serial()
ser.port = "/dev/ttyUSB0"
ser.baudrate = 115200
baudrate = 115200
ser.open()

data=bytearray(b"")
for i in range(5000):
	data+=b'A'
data+=b'F'

ser.write(data)
"""
current = 0
while current!=len(data):
	taille = min(2500,len(data)-current)
	temps = time.time()
	ser.write(data[current:current+taille])
	time.sleep(3)
	current+=taille
"""
ser.close()
