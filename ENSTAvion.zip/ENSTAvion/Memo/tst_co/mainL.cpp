#include <iostream>
#include "serialib.h"
#include <SFML/System.hpp>
#include <unistd.h>

using namespace std;
using namespace sf;



int nb=0;
int er=0;
Mutex mutex;

void affiche()
{
	int v=0;
	int err2=0;
	while (true)
	{
		mutex.lock();
		v=nb;
		nb=0;
		err2=er;
		er=0;
		mutex.unlock();
		cout << v << " b/s Err : "<<err2<<"\n";
		sleep(seconds(1));
	}
}

int main()
{
	cout << "0 ou 1 : ";
	int mode;
	serialib serial;
	char data[1000];
	for (int i=0;i<1000;i++)
		data[i]='A';
	cin >> mode;
	Thread thread(&affiche);
	thread.launch();
	if (mode==0)//emet
	{
		cout << "Emet\n";
		serial.openDevice("/dev/ttyUSB0", 115200);
		while (true)
		{
			serial.writeChar('B');
			usleep(30);
			mutex.lock();
			nb++;
			mutex.unlock();
		}
		serial.closeDevice();
	}
	else
	{
		cout << "Recoit\n";
		serial.openDevice("/dev/ttyUSB0", 115200);
		char c;
		while (true)
		{
			serial.readChar(&c);
			mutex.lock();
			nb++;
			if (c!='A')
				er++;
			mutex.unlock();
		}
		serial.closeDevice();
	}
	
	
	return 0;
	
}
