#include <iostream>
#include "Liaison.hpp"

#include <string>   // for strings
#include <iomanip>  // for controlling float print precision
#include <sstream>  // string to number conversion
#include <vector>

#include <opencv4/opencv2/core.hpp>     // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv4/opencv2/imgproc.hpp>  // Gaussian Blur
#include <opencv4/opencv2/videoio.hpp>
#include <opencv4/opencv2/highgui.hpp>  // OpenCV window I/O
#include <opencv4/opencv2/imgcodecs.hpp>

#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/System.hpp>

using namespace std;
using namespace cv;
using namespace sf;

class Transmission : public Messager
{
public:
	Transmission(string port) : comm(port)
	{
		m_activ = false;
		m_cible = false;
		comm.addMsger('V',this);
	};
	virtual void recepteur(char* data,int size)
	{
		cout << size << endl;
		try {if (m_img[!m_cible].loadFromMemory(data,size))
		{
			m_X = m_img[!m_cible].getSize().x;
			m_Y = m_img[!m_cible].getSize().y;
			m_cible=!m_cible;
			m_activ=true;
		}}
		catch (...) {}
	};
	Image getImg()
	{
		return m_img[m_cible];
	};
	
	bool m_activ;
	int m_X,m_Y;
private:
	Image m_img[2];
	Liaison comm;
	bool m_cible;
};


int main()
{
	Transmission trans("/dev/ttyUSB0");
	while (!trans.m_activ)
		sleep(seconds(0.01));
	
	RenderWindow window(sf::VideoMode(trans.m_X,trans.m_Y), "WebCam");
	Sprite sprite;
	Texture texture;
	
	while (window.isOpen())
	{
		// on traite tous les évènements de la fenêtre qui ont été générés depuis la dernière itération de la boucle
		sf::Event event;
		while (window.pollEvent(event))
		{
			// fermeture de la fenêtre lorsque l'utilisateur le souhaite
			if (event.type == sf::Event::Closed)
			window.close();
		}

		// effacement de la fenêtre en noir
		window.clear(sf::Color::Black);
		
		//modifImg(img);
		texture.loadFromImage(trans.getImg(),IntRect(0,0,trans.m_X,trans.m_Y));
		sprite.setTexture(texture);
		window.draw(sprite);

		// fin de la frame courante, affichage de tout ce qu'on a dessiné
		window.display();
	}
	return 0;
}
