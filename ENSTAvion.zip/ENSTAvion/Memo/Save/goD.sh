g++ mainD.cpp serialib.cpp -O2 -o drone -lopencv_videoio -lopencv_core -lopencv_imgproc -lopencv_highgui -lopencv_imgcodecs -lsfml-system -lsfml-system -lsfml-network
