from ROS_Troll_py import *
from laisonSerie import *
import time

fin = False

def func(data):
	print(data)

def close(data):
	if data==b'over':
		fin = True

ros_send = ROS_Troll_S(b'entrer')
usb_link = Liaison("/dev/ttyUSB0",115200,ros_send.send)
ros_recp = ROS_Troll_R(b'sortie',usb_link.envoi)

usb_link.start()

a=input("finit ? : ")

ros_recp.finit()

