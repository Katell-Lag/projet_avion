g++ ROS_Troll.cpp ROS_Troll_cpp.cpp -O2 -o ROS_Troll -lsfml-system -lsfml-network
