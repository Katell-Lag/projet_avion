#ifndef MESSAGER_H_INCLUDED
#define MESSAGER_H_INCLUDED
class Messager
{
public:
	Messager(){};
	virtual void recepteur(char* data,int size){};
};
#endif

#ifndef LIAISON_H_INCLUDED
#define LIAISON_H_INCLUDED

#include <iostream>
#include "serialib.h"
#include <unistd.h>
#include <SFML/System.hpp>
#include <vector>

using namespace std;
using namespace sf;

class Liaison : public Messager
{
public:
	Liaison(string port) : m_thread(&Liaison::recoit, this)
	{
		m_serial.openDevice(port.c_str(), 115200);
		m_thread.launch();
	}
	~Liaison()
	{m_thread.terminate();m_serial.closeDevice();}
	
	
	void send(char type,char *data,int taille)
	{
		char dataS[10000];
		m_mutex.lock();
		dataS[0]='D';
		dataS[1]=type;
		int compteur = 2;
		for (int i=0;i<taille;i++)
		{
			if (data[i]=='D')
			{
				dataS[compteur] = '\\';
				compteur++;
				dataS[compteur] = '1';
				compteur++;
			}
			else if (data[i]=='F')
			{
				dataS[compteur] = '\\';
				compteur++;
				dataS[compteur] = '2';
				compteur++;
			}
			else if (data[i]=='\\')
			{
				dataS[compteur] = '\\';
				compteur++;
				dataS[compteur] = '\\';
				compteur++;
			}
			else
			{
				dataS[compteur] = data[i];
				compteur++;
			}
		}
		dataS[compteur] = 'F';
		compteur++;
		expedition(dataS,compteur);
		m_mutex.unlock();
	}
	void addMsger(char c,Messager *msger)
	{
		m_Id.push_back(c);
		m_func.push_back(msger);
	}
	
private:
	void recoit()
	{
		char data[10000];
		char c;
		bool lire = false;
		int compte = 0;
		while (true)
		{
			m_serial.readChar(&c);
			if (c=='F')
			{
				lire = false;
				lit(data,compte);
				compte=0;
			}
			else if (c=='D')
			{
				lire = true;
			}
			else if (lire)
			{
				data[compte]=c;
				compte++;
			}
			if (compte==10000)
			{
				compte=0;
				lire = false;
			}
		}
	}
	void lit(char* data,int size)
	{
		char data_R[10000];
		int compteur = 0;
		bool special=false;
		for (int i=0;i<size;i++)
		{
			if (special)
			{
				if (data[i]=='1')
					data_R[compteur]='D';
				else if (data[i]=='2')
					data_R[compteur]='F';
				else
					data_R[compteur]=data[i];
				compteur++;
				special=false;
			}
			else
			{
				if (data[i]=='\\')
					special=true;
				else if (data[i]!='D' && data[i]!='F')
				{
					data_R[compteur]=data[i];
					compteur++;
				}
			}
		}
		for (int i=0;i<m_Id.size();i++)
			if (m_Id[i]==data_R[0])
				m_func[i]->recepteur(&data_R[1],compteur-1);
		
	}
	void expedition(char *data,int taille)
	{
		for (int i=0;i<taille;i++)
		{
			m_serial.writeChar(data[i]);
			usleep(30);
		}
	}

	Thread m_thread;
	Mutex m_mutex;
	serialib m_serial;
	
	vector<char> m_Id;
	vector<Messager*> m_func;
};
#endif
