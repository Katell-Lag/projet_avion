#include "Liaison.hpp"

#include <iostream> // for standard I/O
#include <string>   // for strings
#include <iomanip>  // for controlling float print precision
#include <sstream>  // string to number conversion
#include <vector>
#include <fstream>

#include <opencv2/core.hpp>     // Basic OpenCV structures (cv::Mat, Scalar)
#include <opencv2/imgproc.hpp>  // Gaussian Blur
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>  // OpenCV window I/O
#include <opencv2/imgcodecs.hpp>

#include <SFML/System.hpp>

using namespace std;
using namespace cv;


int main()
{
	VideoCapture cam(0);
	
	if ( !cam.isOpened())
	{
		cout  << "Could not open reference 0" << endl;
		return -1;
	}
	Mat frame;
	Mat petite;
	
	Liaison commu("/dev/ttyUSB0");
	
	vector<int> compression_params;
	compression_params.push_back(IMWRITE_JPEG_QUALITY);
	compression_params.push_back(10);
	string ext("*.jpeg");
	
	Clock clock;
	clock.restart();
	
	while(true)
	{
		clock.restart();
		cam.read(frame);
		double fact = 360./frame.size().width;
		resize(frame, petite, Size(), fact,fact);
		vector<unsigned char> buf;
		cv::imencode(ext,petite,buf,compression_params);
		cout << clock.restart().asSeconds() << endl;
		commu.send('V',(char*)&(buf[0]),buf.size());
	}
	return 0;
}
