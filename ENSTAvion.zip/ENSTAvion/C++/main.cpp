#include <iostream>
#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;

class RenderWind : public RenderWindow
{
public:
	RenderWind(VideoMode a,string b) : RenderWindow(a,b){}
	void onResize(){}
};

int main()
{
	RenderWind window(VideoMode(200, 200), "ENSTAvion");
	CircleShape shape(100.f);
	shape.setFillColor(sf::Color::Green);
	
	while (window.isOpen())
	{
		Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
			window.close();
		}

		window.clear(Color::Black);
		window.draw(shape);
		//cout << window.getSize().x << " "<< window.getView().getSize().x << endl;
		window.display();
	}

    return 0;
}
