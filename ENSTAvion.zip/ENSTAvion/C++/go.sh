g++ *.cpp -o exec -lsfml-graphics -lsfml-window -lsfml-system
